import java.util.ArrayList;
import java.util.List;
interface Demo1{
	public default void method1(){
		System.out.println(" method1 - demo1 default");
	}
}
interface Demo2{
	public default void method1(){
		System.out.println(" method1 - demo2 default");
	}
}
class Demo implements Demo1, Demo2
{
	@Override
	public void method1() {
		System.out.println(" in method1 of Demo Class ");
	}
	}
public class Test3 {

	public static void main(String[] args) {
		Demo1 d = new Demo();
		
		d.method1();
	}

}
