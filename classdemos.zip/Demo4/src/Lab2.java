import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab2 {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(10); list.add(13); list.add(50); list.add(101); list.add(4000); list.add(3);
		System.out.println(list);
		Optional<Integer> min = list.stream().min((n1,n2)->n1.compareTo(n2));
		if (min.isPresent())
				System.out.println("Min = " + min.get());
		list.stream().filter((x)->x<100).forEach(System.out::println);

		IntStream intstr = IntStream.of(10,13,50,101,4000,3);
		IntStream instrr=list.stream().mapToInt((x)->x.intValue());
		System.out.println("Min = " + instrr.min().getAsInt());
		System.out.println("Max = " +intstr.max().getAsInt());
		list.stream().mapToInt((x)->x.intValue()).sorted().forEach(System.out::println);
	}

}
