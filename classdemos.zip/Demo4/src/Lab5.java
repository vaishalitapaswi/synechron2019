import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Lab5 {

	public static void main(String[] args) {
		List<Emp> list = EmpManager.create();
	
		double d = list.stream().filter((e)->e.getDept().equalsIgnoreCase("HR")).mapToDouble((e)->e.getSalary()).sum();	
		System.out.println("HR Salary = " + d);
		double d1 = list.stream().mapToDouble((e)->e.getSalary()).sum();	
		System.out.println("Total Salary = " + d1);
		list.stream().map((e)->e.getDept()).distinct().forEach(System.out::println);
	
		// sum of salaries as per dept
		Map<String,Double> mymap =
					list.stream()	.collect(
							Collectors.groupingBy(
									(e)->e.getDept(),	
									Collectors.summingDouble((e)-> e.getSalary())));
		System.out.println(mymap);
						
		double  sum  = mymap.values().stream().mapToDouble((v)->v.doubleValue()).sum();
		System.out.println("SUm = " + sum);
		
		// sum of salaries as per dept
		Map<String,Long> mymap1 =
					list.stream()	.collect(
							Collectors.groupingBy(
									(e)->e.getEname(),	
									Collectors.counting()));
		System.out.println(mymap1);

	}

}
