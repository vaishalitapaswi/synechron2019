import java.util.List;
import java.util.stream.Collectors;

public class Lab3 {

	public static void main(String[] args) {
		List<Emp> list = EmpManager.create();
	list.stream().map((e)->{
			e.setEname(e.getEname().toUpperCase());
			return e;
		}).forEach(System.out::println);

		list.stream().map((e)->e.getSalary()).sorted().forEach(System.out::println);
	}

}
