import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Lab6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		List<Emp> list = EmpManager.create();
	    long  max = list.size();
	    System.out.println("Max = " + max);
	    int start = 0, count =15;
	    do {
	     	list.stream().skip(start).limit(count).forEach(System.out::println);
	    	start += count;
	    	System.out.println("Press Y to continue ...");
	    }while(scanner.next().equals("Y")  && start < max);
	}

}
