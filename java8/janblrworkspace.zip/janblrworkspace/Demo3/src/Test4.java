interface Sample1{
	public static void m1(){
		System.out.println("static m1 - Sample1 ");
	}
}
interface Sample2{
	public static void m1(){
		System.out.println("static m1 - Sample2 ");
	}
}
interface Sample3 extends Sample1, Sample2
{

}
class SampleImpl implements Sample1{
	public static void m1(){
		System.out.println("m1 - SamplImpl ");
		System.out.println("Try calling static of interface");
		Sample1.m1();
	}
}
public class Test4 {

	public static void main(String[] args) {
	Sample1.m1();
	Sample2.m1();
	
	SampleImpl impl = new SampleImpl();
	SampleImpl.m1();
	

	}

}
