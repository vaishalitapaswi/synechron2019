import java.util.ArrayList;
import java.util.List;
interface Manager<T>
{
	public List<T> getlist();
	public default void create(T t)
	{
		System.out.println("in create of Manager");
		getlist().add(t);
	}
}
class Dept{}
class DeptManager implements Manager<Dept>{
	List<Dept> list = new ArrayList<>();
	public List<Dept> getlist(){
		return list;
	}
}
class Emp{}
class EmpManager  implements Manager<Emp>{
	List<Emp> list = new ArrayList<>();
	public List<Emp> getlist(){
		return list;
	}
	public  void create(Emp t)
	{
		System.out.println("in create of EmpManager - customized for some thing");
		getlist().add(t);
	}
}
public class Test2 {

	public static void main(String[] args) {
		DeptManager deptmgr = new DeptManager();
		deptmgr.create(new Dept());
		EmpManager empmgr = new EmpManager();
		empmgr.create(new Emp());
	}

}
