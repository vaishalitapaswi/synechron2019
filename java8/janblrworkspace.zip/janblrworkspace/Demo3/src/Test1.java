public class Test1 {
	public static void main(String[] args) {
		Operation<Integer> add = (i, j) -> i+j;
		System.out.println("Sum of 20, 10  =  " + add.process(20, 10));
		Operation<Integer> sub = (i, j) -> i - j;
		System.out.println("Sum of 20, 10  =  " + sub.process(20, 10));
		Operation<String> addstr = (i, j) -> i+j;
		System.out.println("Sum of Vaishali, Tapaswi  =  " + addstr.process("Vaishali", "Tapaswi"));
		Operation<Double> addd = (i, j) -> i+j;
		System.out.println("Sum of 20.22, 10.222  =  " + addd.process(20.22, 10.222));
	}
}

@FunctionalInterface
interface Operation<T> {
	public T process(T i, T j);
	//public void add();
}
/*
class Add implements Operation {
	@Override
	public int process(int i, int j) {
		return i + j;
	}
}

class Sub implements Operation {
	@Override
	public int process(int i, int j) {
		return i - j;
	}

}
*/
