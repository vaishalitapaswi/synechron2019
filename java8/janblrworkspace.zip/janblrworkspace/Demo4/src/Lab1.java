import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lab1 {

	public static void main(String[] args) {
		Stream<String> str = Stream.of("AA","BB","CC","DD","EE");
		str.forEach(System.out::println);
		System.out.println("\n\n");
	
		
		List<String> list = Stream.of("AA","BB","CC","DD","EE").collect(Collectors.toList());
		list.stream().forEach(System.out::println);
		System.out.println("\n\n");
		list.stream().forEach(System.out::println);

	}

}
