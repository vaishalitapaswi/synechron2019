import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Lab4 {

	public static void main(String[] args) {
		List<Emp> list = EmpManager.create();
	
		Predicate<Emp> pr1 =(e)->e.getSalary() > 1050 ; //Salary > x
		Predicate<Emp> pr2 =(e)->e.getSalary() < 1010 ; //Salary < x
		Predicate<Emp> pr3 =(e)->e.getSalary() > 1010   && e.getSalary()< 1050   ; // salary bt x and y
		// option for pr3  	list.stream().filter((e)->e.getSalary() > 1030).peek(System.out::println).filter((e)->e.getSalary()< 1050 ).forEach(System.out::println);
		
		Predicate<Emp> pr0 =(e)-> e.getDept().equals("HR") || e.getEname().startsWith("s");
		
		list.stream().filter(pr0	).forEach(System.out::println);

		
	}

}
