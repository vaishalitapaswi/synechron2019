import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab7 {

	public static void main(String[] args) {
		
		List<String> list = Stream.of("AA","BB","CC","DD","EE").collect(Collectors.toList());
		
		String str =  list.stream().reduce((s,s1)->{
			System.out.println("s = "  + s +", s1= "+ s1 );
			return s+s1;
		}).toString();
		System.out.println(str);
		
		
		IntStream intstr = IntStream.of(10,16,4,12,8,10);
		int min = intstr.reduce((i, i1)->i > i1?i1:i).getAsInt();
				System.out.println(" Sum = " + min);
	}

}
