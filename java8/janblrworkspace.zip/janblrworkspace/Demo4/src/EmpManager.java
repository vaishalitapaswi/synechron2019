import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EmpManager {
	public static void main(String[] args) {
		create().forEach(System.out::println);
	}
	public static List<Emp> create(){
		List<Emp> list = new ArrayList<>();
		
		List<String> names = Arrays.asList("Simran","saloni","Vaishali","Vishal","Usha");
		List<String> depts = Arrays.asList("HR","Training","Fin","admin");
		
		for (int i = 1; i< 100;i++)
		{
			
			Emp e = new Emp();
			e.setEmpno(i);
			e.setEname(names.get(i % names.size() ));
			e.setDept(depts.get(i % depts.size() ));
			e.setSalary(i);
		//	System.out.println(e);
			list.add(e);
		}
		return list;
	}
}
