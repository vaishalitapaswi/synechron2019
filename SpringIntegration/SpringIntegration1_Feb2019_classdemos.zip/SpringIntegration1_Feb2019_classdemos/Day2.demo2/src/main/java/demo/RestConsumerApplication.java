package demo;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication(scanBasePackages="controllers")
public class RestConsumerApplication {
	public static void thirdcontrollerclient(){
		String url = "http://localhost:8080/third";
		RestTemplate template = new RestTemplate();
		System.out.println("Get Returned default " + template.getForEntity(url ,String.class).getBody());
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.TEXT_HTML));
		HttpEntity entity = new HttpEntity("",headers); 
		System.out.println("Get Returned default " + template.exchange(url, HttpMethod.GET,
				entity, String.class));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		 entity = new HttpEntity("",headers); 
		System.out.println("Get Returned default " + template.exchange(url, HttpMethod.GET,
				entity, String.class));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		 entity = new HttpEntity("",headers); 
		System.out.println("Get Returned default " + template.exchange(url, HttpMethod.GET,
				entity, String.class));
	}
	
	public static void secondcontrollerclient(){
		String url = "http://localhost:8080/second";
		RestTemplate template = new RestTemplate();
		System.out.println("/m1 Get Returned " + template.getForEntity(url + "/m1",String.class).getBody());
		System.out.println("/m2 Get Returned " + template.getForEntity(url + "/m2",String.class).getBody());
	}
	public static void firstcontrollerclient(){
		String url = "http://localhost:8080/first";
		RestTemplate template = new RestTemplate();
		ResponseEntity<String> respentity = template.getForEntity("http://localhost:8080/first",String.class);
		if (respentity.getStatusCode()==HttpStatus.OK)
			//respentity.getStatusCodeValue() == 200
		{
		System.out.println("ToString = " + respentity.toString());
		System.out.println("Body = " + respentity.getBody());
		}
		System.out.println("Get Returned " + template.getForEntity(url,String.class).getBody());
		System.out.println("Post Returned " + template.postForEntity(url, null, String.class).getBody());
		template.put(url,null);
		template.delete(url);
	}
	public static void main(String[] args) {
		//SpringApplication.run(RestConsumerApplication.class, args);
		//firstcontrollerclient();
		//secondcontrollerclient();
		thirdcontrollerclient();
		
		
	}
	
	
}
