package reqres;

import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class PatchConsumer {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users/2";
		RestTemplate template = new RestTemplate();
		template.setInterceptors(Collections.singletonList(new MyInterceptor()));
		User u = new User();
		u.setName("Fands" ); u.setJob("TComp" );
		HttpEntity<User> httpentity = new HttpEntity<>(u);
		
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		template.setRequestFactory(requestFactory);
		
		
		ResponseEntity<String> str = template.exchange(url,HttpMethod.PATCH,httpentity,String.class);
		System.out.println("Returned = " + str);
/*		
		<dependency>
		<groupId>org.apache.httpcomponents</groupId>
		<artifactId>httpclient</artifactId>
	</dependency>

	*/
		
	//	template.put(url,u);
	}

}
