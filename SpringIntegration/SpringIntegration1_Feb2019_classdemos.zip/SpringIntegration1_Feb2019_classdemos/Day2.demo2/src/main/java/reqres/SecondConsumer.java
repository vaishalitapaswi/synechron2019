package reqres;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;
class MyInterceptor implements ClientHttpRequestInterceptor{

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] args, ClientHttpRequestExecution requestexecution)
			throws IOException {
		request.getHeaders().add("user-agent", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36");
		return requestexecution.execute(request, args);
	}
	
}
public class SecondConsumer {
public static void main(String[] args) {
	String url = "https://reqres.in/api/users/3";
	RestTemplate template = new RestTemplate();
	//template.setInterceptors(Arrays.asList(new MyInterceptor()));
	template.setInterceptors(Collections.singletonList(new MyInterceptor()));
	
	ResponseEntity<String> respentity = template.getForEntity(url,String.class);
	if (respentity.getStatusCode()==HttpStatus.OK)
		//respentity.getStatusCodeValue() == 200
	{
	System.out.println("ToString = " + respentity.toString());
	System.out.println("Body = " + respentity.getBody());
	}
}
}
