package controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/first")
public class FirstController {
	//@RequestMapping(method=RequestMethod.GET)
	@GetMapping()
	public String m1(){
		String str = "Get in m1 - FirstController";
		System.out.println(str);
		return str;
	}
	@PostMapping()
	public String m2(){
		String str = "POST in m2 - FirstController";
		System.out.println(str);
		return str;
	}
	@PutMapping()
	public String m3(){
		String str = "PUT in m3 - FirstController";
		System.out.println(str);
		return str;
	}
	@DeleteMapping()
	public String m4(){
		String str = "DELETE in m4 - FirstController";
		System.out.println(str);
		return str;
	}
	@PatchMapping()
	public String m5(){
		String str = "PATCH in m5 - FirstController";
		System.out.println(str);
		return str;
	}
	
}
