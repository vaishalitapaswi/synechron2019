package demo;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;


@Component
public class InboundEndpoint {
	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	
	public Message<?> get(Message<?> msg) {
		log.info("GET method");
		List<Flight> flights = new ArrayList<Flight>();
		flights.add(new Flight("PNQ","DEL","20"));
		flights.add(new Flight("DEL","PNQ","21"));
		flights.add(new Flight("HYD","PNQ","22"));
		flights.add(new Flight("PNQ","HYD","23"));
		flights.add(new Flight("BLR","PNQ","25"));
		flights.add(new Flight("PNQ","BLR","25"));
		flights.add(new Flight("PNQ","DEL","20"));
		flights.add(new Flight("DEL","PNQ","21"));
		flights.add(new Flight("HYD","PNQ","22"));
		flights.add(new Flight("PNQ","HYD","23"));
		flights.add(new Flight("BLR","PNQ","25"));
		flights.add(new Flight("PNQ","BLR","25"));
		flights.add(new Flight("PNQ","DEL","20"));
		flights.add(new Flight("DEL","PNQ","21"));
		flights.add(new Flight("HYD","PNQ","22"));
		flights.add(new Flight("PNQ","HYD","23"));
		flights.add(new Flight("BLR","PNQ","25"));
		flights.add(new Flight("PNQ","BLR","25"));
		flights.add(new Flight("PNQ","DEL","20"));
		flights.add(new Flight("DEL","PNQ","21"));
		flights.add(new Flight("HYD","PNQ","22"));
		flights.add(new Flight("PNQ","HYD","23"));
		flights.add(new Flight("BLR","PNQ","25"));
		flights.add(new Flight("PNQ","BLR","25"));
		flights.add(new Flight("PNQ","DEL","20"));
		flights.add(new Flight("DEL","PNQ","21"));
		flights.add(new Flight("HYD","PNQ","22"));
		flights.add(new Flight("PNQ","HYD","23"));
		flights.add(new Flight("BLR","PNQ","25"));
		flights.add(new Flight("PNQ","BLR","25"));
		flights.add(new Flight("PNQ","DEL","20"));
		flights.add(new Flight("DEL","PNQ","21"));
		flights.add(new Flight("HYD","PNQ","22"));
		flights.add(new Flight("PNQ","HYD","23"));
		flights.add(new Flight("BLR","PNQ","25"));
		flights.add(new Flight("PNQ","BLR","25"));
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return MessageBuilder.withPayload(flights).copyHeadersIfAbsent(msg.getHeaders())
				.setHeader("http_statusCode", HttpStatus.OK).build();
	}
	
}
