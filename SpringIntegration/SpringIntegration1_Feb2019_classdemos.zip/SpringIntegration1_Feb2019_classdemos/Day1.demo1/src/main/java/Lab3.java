import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

class Lab3Helper implements Callable<Integer>
{
	int i =0;
	int j =0;
	public Lab3Helper(int i, int j ){
		this.i = i; this.j = j;
	}
	public Integer call() throws Exception {
		System.out.println(" in add " + i  + ",  " + j);
		return (i+j);
	}
}
public class Lab3 {

	public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException {
		Lab3Helper helper = new Lab3Helper(10, 20);
	Future<Integer> ret = 	Executors.newSingleThreadExecutor().submit(helper);
	System.out.println(ret.get(10,TimeUnit.MICROSECONDS));
	}

}
