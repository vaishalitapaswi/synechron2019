package demo;

import org.springframework.integration.annotation.Transformer;
import org.springframework.stereotype.Component;

@Component
public class MyTrans {
	@Transformer
	public String change(String s){
		return s.toUpperCase();
	}
}
