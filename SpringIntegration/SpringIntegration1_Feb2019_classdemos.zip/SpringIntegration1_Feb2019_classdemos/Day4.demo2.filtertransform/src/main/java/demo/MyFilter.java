package demo;

import java.io.File;

import org.springframework.integration.core.MessageSelector;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

//@Component(value="myfilter")
public class MyFilter implements MessageSelector {

	public MyFilter() {
		System.out.println("MyFilter Constructor.. ");
	}
	@Override
	public boolean accept(Message<?> msg) {
		System.out.println("Accept - Headers = " + msg.getHeaders() + " , payload = " + msg.getPayload());
		if (msg.getPayload() instanceof File)
		{
			File f1 = (File)msg.getPayload();
			if (f1.getName().startsWith("info"))
				return true;
			else
				return false;
		}
		else
			return false;
	}

}
