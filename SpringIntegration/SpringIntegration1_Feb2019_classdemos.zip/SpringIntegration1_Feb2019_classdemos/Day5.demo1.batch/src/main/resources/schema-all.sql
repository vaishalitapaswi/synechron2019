DROP TABLE emptable IF EXISTS;

create table emptable (empno numeric(2), ename varchar(20), salary numeric(10,2));