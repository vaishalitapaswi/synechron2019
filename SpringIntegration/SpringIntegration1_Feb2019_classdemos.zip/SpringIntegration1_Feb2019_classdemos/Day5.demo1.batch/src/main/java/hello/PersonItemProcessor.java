package hello;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.jmx.export.annotation.ManagedResource;

public class PersonItemProcessor implements ItemProcessor<Person, Emp> {

    private static final Logger log = LoggerFactory.getLogger(PersonItemProcessor.class);
    private static int empno  =0;
    @Override
    public Emp process(final Person person) throws Exception {
        final Emp emp =new Emp();
        emp.setEmpno(empno++);
        emp.setEname(person.getFirstName() + "  " + person.getLastName());
        emp.setSalary(Math.random()*1000);
          return emp;
    }

}