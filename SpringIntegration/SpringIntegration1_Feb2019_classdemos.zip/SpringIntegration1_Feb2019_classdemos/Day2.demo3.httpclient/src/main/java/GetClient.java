import java.io.IOException;

import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHttpRequest;

public class GetClient {

	public static void main(String[] args) throws Exception
	{
		HttpClient client = HttpClients.createDefault();
		HttpHost httphost = new HttpHost("reqres.in");
		HttpRequest request = new BasicHttpRequest("GET","/api/users");
	
		ResponseHandler<String> rhandler = new BasicResponseHandler() ;
		String str;
		
		str = client.execute(httphost, request, rhandler);
		System.out.println(str);
		
	
	}

}
