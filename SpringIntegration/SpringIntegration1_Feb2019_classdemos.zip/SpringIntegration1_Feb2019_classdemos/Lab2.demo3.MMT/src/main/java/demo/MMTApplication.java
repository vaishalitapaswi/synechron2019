package demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("demo1.xml")
@EnableMBeanExport
public class MMTApplication {

	public static void main(String[] args) {
		SpringApplication.run(MMTApplication.class, args);
		while(true){}
	}

}
