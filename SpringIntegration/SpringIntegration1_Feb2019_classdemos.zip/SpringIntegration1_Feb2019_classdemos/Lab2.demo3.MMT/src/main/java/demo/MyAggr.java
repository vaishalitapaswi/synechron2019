package demo;

import java.util.List;

import org.springframework.integration.annotation.Aggregator;
import org.springframework.integration.annotation.CorrelationStrategy;
import org.springframework.integration.annotation.ReleaseStrategy;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
@Component
public class MyAggr {
	public MyAggr() {
	System.out.println("in constructor ");
	}
	@Aggregator
	  public String aggregatingMethod(List<String> results) {
		  String str = "";
		    for (String str1: results) {
		     str+= str1;
		    }
		    System.out.println("Aggregating Method = " + str);
		    return str;
		  }

	  @ReleaseStrategy
	  public boolean releaseChecker(List<Message<?>> messages) {
		  boolean bool ;
		  System.out.println("in real" + messages);
		if (messages.size() >= 2)
				bool =  true;
		else
				bool =  false;
		System.out.println("in release checker =" + bool);
		return bool;
	  }

	  @CorrelationStrategy
	  public String correlateBy(String item) {
		  System.out.println("in corrlate by id " + item);
		  return "1";
	  }
}