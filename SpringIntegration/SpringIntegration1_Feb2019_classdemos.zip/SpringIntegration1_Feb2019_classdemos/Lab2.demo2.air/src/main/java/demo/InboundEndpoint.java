package demo;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;


@Component
public class InboundEndpoint {
	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	
	public Message<?> get(Message<?> msg) {
		log.info("GET method");
		List<Flight> flights = new ArrayList<Flight>();
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		flights.add(new Flight("PNQ","DEL","1",1));
		flights.add(new Flight("DEL","PNQ","2",2));
		flights.add(new Flight("HYD","PNQ","3",1));
		flights.add(new Flight("PNQ","HYD","4",1));
		
		return MessageBuilder.withPayload(flights).copyHeadersIfAbsent(msg.getHeaders())
				.setHeader("http_statusCode", HttpStatus.OK).build();
	}

	public Message<?> getone(Message<?> msg) {
		log.info("GET method");
		Flight flt = new Flight("PNQ","DEL","1",1);
		
		
		return MessageBuilder.withPayload(flt).copyHeadersIfAbsent(msg.getHeaders())
				.setHeader("http_statusCode", HttpStatus.OK).build();
	}
}
