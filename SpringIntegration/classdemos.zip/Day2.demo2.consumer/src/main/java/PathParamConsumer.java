import org.springframework.web.client.RestTemplate;

public class PathParamConsumer {
	public static void main(String[] args) {
		String url = "http://localhost:8080/pp";
	 RestTemplate template = new RestTemplate();
	 
	 System.out.println(template.getForEntity(url +"/hello/Check" ,String.class).getBody());
	 System.out.println(template.getForEntity(url + "/divide/100/20" ,String.class).getBody());
	

	}
}
