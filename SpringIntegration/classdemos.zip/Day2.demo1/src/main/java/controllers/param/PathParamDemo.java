package controllers.param;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/pp")
public class PathParamDemo {
	@GetMapping(value="/hello/{nm}")
	public String hello(@PathVariable(name="nm")String name){
		return "<h1>Hello, "+ name + "</h1>";
	}
	@GetMapping(value="/divide/{n1}/{n2}")
	public String divide(@PathVariable(name="n1") int no1, @PathVariable(name="n2")int no2)
	{
		return "<h1> Ans = " +  (no1/no2)   + "</h1>";
	}
}
