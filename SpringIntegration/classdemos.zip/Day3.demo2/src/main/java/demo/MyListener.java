package demo;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

//@Component
public class MyListener {
	@JmsListener(destination="MyQueue")
	public void receivedata(Emp s)
	{
		System.out.println("Received - " + s);
	}
}
