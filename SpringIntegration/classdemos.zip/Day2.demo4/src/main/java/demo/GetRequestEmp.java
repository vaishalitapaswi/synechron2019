package demo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;


public class GetRequestEmp {

	public static void main(String[] args) {
		String url = "http://localhost:8080/emp";
		 RestTemplate template = new RestTemplate();
		 HttpHeaders headers = new HttpHeaders();
		 List<MediaType> list =new ArrayList<MediaType>();
		 
		 list.add(MediaType.TEXT_HTML);
		 list.add(MediaType.APPLICATION_XML);

		 
     	 headers.setAccept(list);
		 HttpEntity<String> httpentity = new HttpEntity<String>("parameters",headers);
	
		 ResponseEntity<String> str = template.exchange(url, HttpMethod.GET,httpentity, String.class);

		 System.out.println(str.getBody());
		 
	}

}
