package demo;


import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


public class PostRequest {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users/2";
		 RestTemplate template = new RestTemplate();
		 template.getInterceptors().add(new MyInterceptor());
		 User user  = new User("Vaishali","CT");
		 ResponseEntity<String> str  = template.postForEntity(url, user, String.class);
		 System.out.println(str.getBody());
		 
	}

}
