package demo;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;


public class GetRequestWithInterceptor {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users/2";
		 RestTemplate template = new RestTemplate();

		 template.getInterceptors().add(new MyInterceptor());
		 ResponseEntity<String> str  = template.getForEntity(url,String.class);
		 System.out.println(str.getBody());
		 
	}

}
