package demo;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


public class PutDeleteRequest {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users/2";
		 RestTemplate template = new RestTemplate();

		 template.getInterceptors().add(new MyInterceptor());
		 User user  = new User("Vaishali","CT");
		 HttpEntity httpentity = new HttpEntity(user);
	
	   	 template.put(url, user);
		 ResponseEntity<String> str = template.exchange(url, HttpMethod.PUT, httpentity, String.class);
		 System.out.println(str.getBody());
		 
		 
		 template.delete(url);
		 ResponseEntity<String> str1= template.exchange(url,HttpMethod.DELETE,null,String.class);
		 System.out.println(str1.getStatusCode());
	}

}
