package demo;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;


public class GetRequest {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users/2";
		 RestTemplate template = new RestTemplate();
		 HttpHeaders headers = new HttpHeaders();
	
		 headers.add("User-Agent", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
		 HttpEntity<String> httpentity = new HttpEntity<String>("parameters",headers);
	
		 ResponseEntity<String> str = template.exchange(url, HttpMethod.GET,httpentity, String.class);

		 
		 System.out.println(str.getBody());
		 
	}

}
