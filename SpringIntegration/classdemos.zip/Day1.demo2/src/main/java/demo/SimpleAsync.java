package demo;

import java.util.concurrent.Future;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

@Component
public class SimpleAsync {
	@Async
	public void method5(){
		System.out.println(" start of method 5.. " + Thread.currentThread().getName());
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	System.out.println(" end of method 5.. ");
	}

@Async
public Future<String> method6(){
	System.out.println(" start of method 6.. " + Thread.currentThread().getName());
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

System.out.println(" end of method 6.. ");
return new AsyncResult<String>("Return from Method6");
}
}