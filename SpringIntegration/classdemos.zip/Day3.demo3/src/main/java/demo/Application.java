package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.file.FileNameGenerator;
import org.springframework.messaging.Message;

/*class  MyFNG implements FileNameGenerator
{
	@Override
	public String generateFileName(Message<?> arg0) {
		System.out.println(arg0);
		return arg0.getHeaders().getTimestamp()+".txt";
}
	}*/
@SpringBootApplication
@ImportResource(value="demo1.xml")
public class Application {

	@Bean
	public FileNameGenerator mygen(){
		return mygen;
	}

	FileNameGenerator mygen = (m)->m.getHeaders().getTimestamp()+".txt" ; 
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		while(true){}
	}

}
