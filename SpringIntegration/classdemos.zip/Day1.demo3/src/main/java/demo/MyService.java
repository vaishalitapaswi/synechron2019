package demo;

import java.util.concurrent.Future;

import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MyService {
	@Async
	public Future<String> getdata(){
		RestTemplate template = new RestTemplate();
		
		ResponseEntity<String> restr = template.getForEntity("http://trnroom2-01:8080/invoke", String.class);
		return new AsyncResult<String>(restr.getBody());
	}
}
