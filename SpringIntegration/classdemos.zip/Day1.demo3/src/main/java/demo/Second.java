package demo;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class Second {
	ScheduledFuture sf;
	Runnable r = ()->{
		System.out.println(" in scheduled method " + new Date() + " , in " + Thread.currentThread().getName());
	};
	
	@GetMapping(value="/start")
	public String start(){
		System.out.println("in start ");
		ScheduledExecutorService executor  = Executors.newScheduledThreadPool(1);
		sf= executor.scheduleWithFixedDelay(r, 0, 10, TimeUnit.SECONDS);
		return "index.html";
	}
	@GetMapping(value="/stop")
	public String stop(){
		System.out.println("in stop");
		sf.cancel(true);
		return "index.html";
	}
}
