package demo;
import java.lang.management.ManagementFactory;
import java.util.Scanner;

import javax.management.MBeanServer;
import javax.management.MXBean;
import javax.management.ObjectName;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

@Component
@ManagedResource
public class First  {
	
	private int no1;
	private String name;
	@ManagedAttribute
	public int getNo1() {
		return no1;
	}

	public void setNo1(int no1) {
		this.no1 = no1;
	}
	@ManagedAttribute
	public String getName() {
		return name;
	}
  @ManagedOperation
	public void setName(String name) {
		this.name = name;
	}

	public void print(){
		for(int i = 0; i<5;i++){
			System.out.println("Current name =" + name + ", no1 = " + no1);
		}
	}
	
	
}

