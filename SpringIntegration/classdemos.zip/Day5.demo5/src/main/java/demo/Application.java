package demo;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.EnableMBeanExport;

@SpringBootApplication
@EnableMBeanExport
public class Application {

	public static void main(String[] args) throws Exception {
		ConfigurableApplicationContext ctx = SpringApplication.run(Application.class, args);
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to start ..");
		scanner.nextInt();
		First f1 = ctx.getBean(First.class);
		f1.setName("Simple");
		for(int i = 0;i < 1000;i++)
		{
			f1.setNo1(i);
			f1.print();
			Thread.sleep(5000);
		}
	}

}
